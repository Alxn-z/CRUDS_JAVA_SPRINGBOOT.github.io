package com.example.Backenddemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class BackenddemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackenddemoApplication.class, args);

	}

}
