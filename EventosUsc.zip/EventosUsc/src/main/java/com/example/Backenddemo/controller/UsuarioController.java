package com.example.Backenddemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Backenddemo.model.Usuario;
import com.example.Backenddemo.services.UsuariosService;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    @Autowired
    private UsuariosService usuariosService;

    //Endpoint para listar todos los usuarios:
    //(Usa metodo HTTP get)

    @GetMapping
    public List<Usuario> listarUsuarios()
    {
        return usuariosService.selectAllUsers();

    }

    //Endpoint para guardar un usuario nuevoUsuario
    // (Usuario metodo HTTP Post)
    


    
}
