package com.example.Backenddemo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Backenddemo.model.Evento;
import com.example.Backenddemo.repository.IEventoRepository;

@Service
public class EventosService {

    @Autowired
    private IEventoRepository eventoRepository;

    // OPERACIONES DEL CRUD

    // LISTAR TODOS LOS EVENTOS
    public List<Evento> selectAllEvents() {
        return eventoRepository.findAll();
    }

    // ENCONTRAR SOLO UN EVENTO
    public Optional<Evento> selectById(Long id) {
        return eventoRepository.findById(id);
    }
    
    // CREAR UN NUEVO EVENTO
    public Evento createEvent(Evento nuevoEvento) {
        return eventoRepository.save(nuevoEvento);
    }

    // OTROS MÉTODOS (opcionalmente puedes agregar actualizar y eliminar)
}
