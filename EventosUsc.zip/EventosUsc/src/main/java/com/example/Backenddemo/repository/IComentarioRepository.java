package com.example.Backenddemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Backenddemo.model.Comentario;

public interface IComentarioRepository extends JpaRepository<Comentario, Long> {
    
}
