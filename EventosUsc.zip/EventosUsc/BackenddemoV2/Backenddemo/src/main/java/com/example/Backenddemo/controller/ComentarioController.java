package com.example.Backenddemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Backenddemo.model.Comentario;
import com.example.Backenddemo.services.ComentariosService;

@RestController
@RequestMapping("/api/comentarios")
public class ComentarioController {

    @Autowired
    private ComentariosService comentariosService;

    //Endpoint para listar todos los usuarios:
    //(Usa metodo HTTP get)

    @GetMapping
    public List<Comentario> listarComentarios()
    {
        return comentariosService.selectAllComments();

    }

    //Endpoint para guardar un usuario nuevoUsuario
    // (Usuario metodo HTTP Post)
    


    
}