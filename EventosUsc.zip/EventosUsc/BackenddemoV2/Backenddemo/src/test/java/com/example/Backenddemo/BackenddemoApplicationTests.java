package com.example.Backenddemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackenddemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
