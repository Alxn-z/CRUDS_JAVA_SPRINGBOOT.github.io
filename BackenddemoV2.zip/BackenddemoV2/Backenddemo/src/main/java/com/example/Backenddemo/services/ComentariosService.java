package com.example.Backenddemo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Backenddemo.model.Comentario;
import com.example.Backenddemo.repository.IComentarioRepository;

@Service
public class ComentariosService {

    @Autowired
    private IComentarioRepository comentarioRepository;

    // Listar todos los comentarios
    public List<Comentario> selectAllComments() {
        return comentarioRepository.findAll();
    }

    // Encontrar un comentario por su ID
    public Optional<Comentario> selectById(Long id) {
        return comentarioRepository.findById(id);
    }

    // Crear un nuevo comentario
    public Comentario createComment(Comentario nuevoComentario) {
        return comentarioRepository.save(nuevoComentario);
    }

    // Actualizar un comentario existente
    public Comentario updateComment(Long id, Comentario comentarioActualizado) {
        if (comentarioRepository.existsById(id)) {
            comentarioActualizado.setId(id); // Aseguramos que se use el mismo ID
            return comentarioRepository.save(comentarioActualizado);
        }
        return null; // O puedes lanzar una excepción si prefieres manejar el error
    }

    // Eliminar un comentario por su ID
    public void deleteComment(Long id) {
        comentarioRepository.deleteById(id);
    }
}
