package com.example.Backenddemo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Backenddemo.model.Usuario;
import com.example.Backenddemo.repository.IUsuarioRepository;


    @Service
    public class UsuariosService {

        @Autowired
        private IUsuarioRepository usuarioRepository;

        //IPERACIONES DEL CRUD

        //LISTAR TODOS LOS USUARIOS

        public List <Usuario> selectAllUsers()
        {
            return usuarioRepository.findAll();

        }
        //Encontrar solo un usuario
        public Optional <Usuario> selectById(Long id)
        {
            return usuarioRepository.findById(id);
        }
        
        //Crear
        public Usuario createUser (Usuario nuevoUsuario)
        {
            return usuarioRepository.save(nuevoUsuario);

        }


    }
    

