package com.example.Backenddemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Backenddemo.model.Evento;
import com.example.Backenddemo.services.EventosService;

@RestController
@RequestMapping("/api/eventos")
public class EventoController {

    @Autowired
    private EventosService eventosService;

    // Endpoint para listar todos los eventos
    @GetMapping
    public List<Evento> listarEventos() {
        return eventosService.selectAllEvents();
    }

    // Endpoint para guardar un nuevo evento
    @PostMapping
    public Evento guardarEvento(@RequestBody Evento nuevoEvento) {
        return eventosService.createEvent(nuevoEvento);
    }

    // Aquí puedes agregar otros endpoints como actualizar y eliminar eventos
}
