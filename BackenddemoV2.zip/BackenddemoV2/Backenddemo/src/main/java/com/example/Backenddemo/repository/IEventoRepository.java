package com.example.Backenddemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Backenddemo.model.Evento;

public interface IEventoRepository extends JpaRepository<Evento, Long> {
    
}
